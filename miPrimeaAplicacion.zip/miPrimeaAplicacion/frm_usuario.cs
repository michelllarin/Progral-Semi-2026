﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace miPrimeaAplicacion
{
    public partial class frm_usuario : Form
    {
        public frm_usuario()
        {
            InitializeComponent();
        }

        Conexion objConexion = new Conexion();
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        String accion = "nuevo";
        int posicion = 0;
        private void frm_usuario_Load(object sender, EventArgs e)
        {
            obtenerDatos();
        }

        private void obtenerDatos()
        {
            ds = objConexion.crearDs();
            if (ds.Tables.Contains("usuarios"))
            {
                dt = ds.Tables["usuarios"];
                mostrarDatos();
            }
        }

        private void mostrarDatos()
        {

            if (dt.Rows.Count > 0 && posicion < dt.Rows.Count)
            {
                idUsuario.Text = dt.Rows[posicion]["idUsuario"].ToString();

                // CORREGIDO: Se quitó el espacio dentro de las comillas ("usuario")
                txtUsuario.Text = dt.Rows[posicion]["usuario"].ToString();
                txtClaveUsuario.Text = dt.Rows[posicion]["clave"].ToString();
                txtNombreUsuario.Text = dt.Rows[posicion]["nombre"].ToString();
                txtDireccionUsuario.Text = dt.Rows[posicion]["dirección"].ToString();
                txtTelefonoUsuario.Text = dt.Rows[posicion]["teléfono"].ToString();

                lblRegistrosUsuario.Text = (posicion + 1) + " de " + dt.Rows.Count;
            }
        }

        private void limpiarControles()
        {
            idUsuario.Text = "";
            txtUsuario.Text = "";
            txtClaveUsuario.Text = "";
            txtConfirmarClave.Text = "";
            txtNombreUsuario.Text = "";
            txtDireccionUsuario.Text = "";
            txtTelefonoUsuario.Text = "";
        }

        private void activarDesactivarCtrls(Boolean estado)
        {
            grbDatos.Enabled = estado;
            grbNavegacion.Enabled = !estado;
            btnEliminarUsuario.Enabled = !estado;
        }

        private void btnAgregarAlumno_Click(object sender, EventArgs e)
        {
            if (btnAgregarUsuario.Text == "Agregar")
            {
                btnAgregarUsuario.Text = "Guardar";
                btnModificarUsuario.Text = "Cancelar";

                accion = "nuevo";
                limpiarControles();

                activarDesactivarCtrls(true);
            }
            else
            {
                string usuarioTexto = txtUsuario.Text.Trim();
                if (usuarioTexto.Length < 6 || usuarioTexto.Length > 16)
                {
                    MessageBox.Show("El usuario debe tener entre 6 y 16 caracteres.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtUsuario.Focus();
                    return;
                }

                string clave = txtClaveUsuario.Text;
                string confirmarClave = txtConfirmarClave.Text;

                if (clave != confirmarClave)
                {
                    MessageBox.Show("Las contraseñas no coinciden. Por favor, verifíquelas.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtConfirmarClave.Focus();
                    return;
                }

                bool tieneLetras = System.Text.RegularExpressions.Regex.IsMatch(clave, "[a-zA-Z]");
                bool tieneNumeros = System.Text.RegularExpressions.Regex.IsMatch(clave, "[0-9]");

                if (!tieneLetras || !tieneNumeros)
                {
                    MessageBox.Show("La contraseña debe contener al menos una letra y un número.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtClaveUsuario.Focus();
                    return;
                }

                String[] usuario = {
                    idUsuario.Text,
                    txtUsuario.Text,      
                    txtClaveUsuario.Text,
                    txtNombreUsuario.Text,
                    txtDireccionUsuario.Text,
                    txtTelefonoUsuario.Text
                };

                String respuesta = objConexion.mantenimiento_usuarios_usss119326(usuario, accion);

                if (respuesta != "1")
                {
                    MessageBox.Show(respuesta, "Error al guardar usuarios.", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Usuario guardado con éxito.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    activarDesactivarCtrls(false);
                    btnAgregarUsuario.Text = "Nuevo";
                    btnModificarUsuario.Text = "Modificar";
                    obtenerDatos();
                }
            }

        }

        private void btnModificarUsuario_Click(object sender, EventArgs e)
        {
            if (btnModificarUsuario.Text == "Modificar")
            {
                btnAgregarUsuario.Text = "Guardar";
                btnModificarUsuario.Text = "Cancelar";
                activarDesactivarCtrls(true);
                accion = "modificar";
            }
            else
            {//Guardar
                mostrarDatos();
                activarDesactivarCtrls(false);
                btnAgregarUsuario.Text = "Agregar";
                btnModificarUsuario.Text = "Modificar";
            }


        }

        private void btnSiguienteUsuario_Click(object sender, EventArgs e)
        {
            if(posicion < dt.Rows.Count - 1)
            {
                posicion++;
                mostrarDatos();
            }
            else
            {
                MessageBox.Show("Estás en el último registro.", "Navegación", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnAnteriorUsurio_Click(object sender, EventArgs e)
        {
            if (posicion > 0)
            {
                posicion--;
                mostrarDatos();
            }
            else
            {
                MessageBox.Show("Estás en el primer registro.", "Navegación", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnUltimoUsuario_Click(object sender, EventArgs e)
        {
            if (dt.Rows.Count > 0)
            {
                posicion = dt.Rows.Count - 1;
                mostrarDatos();
            }
        }

        private void btnPrimeroUsuario_Click(object sender, EventArgs e)
        {
            posicion = 0;
            mostrarDatos();
        }

        private void btnEliminarUsuario_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Está seguro de eliminar a " + txtNombreUsuario.Text + "?",
               "Eliminando usuario", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                String respuesta = objConexion.mantenimiento_usuarios_usss119326(
                    new String[] { idUsuario.Text, "", "", "", "", "" }, "eliminar"
                );
                if (respuesta != "1")
                {
                    MessageBox.Show(respuesta, "Error al eliminar usuario.", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    posicion = 0;
                    obtenerDatos();
                }
            }
        }
    }
}
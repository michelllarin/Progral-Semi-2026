﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace miPrimeaAplicacion
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        Conexion objConexion = new Conexion();

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text.Trim();
            string clave = txtClave.Text;

            // Verificamos en la base de datos usando tu método
            bool accesoValido = objConexion.validarUsuario(usuario, clave);

            if (accesoValido)
            {
                MessageBox.Show("¡Acceso concedido!", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information); // o MessageBoxButtons.OK

                // 1. Abrimos el formulario que contiene la tabla de usuarios
                frm_usuario formUsuariosTabla = new frm_usuario();
                formUsuariosTabla.Show();

                // 2. Cerramos la ventana de login actual
                this.Close();
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUsuario.Clear();
                txtClave.Clear();
                txtUsuario.Focus();
            }
        }
    }
}

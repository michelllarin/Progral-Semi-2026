﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data; //Esta libreria es para usar bases de datos
using System.Data.SqlClient; //Esta libreria permite usar SQLServer

namespace miPrimeaAplicacion {
    internal class Conexion {
        //Definir los miembros, atributos y metodos de la clase
        public SqlConnection objConexion = new SqlConnection(); //Conectarme a la BD
        public SqlCommand objComando = new SqlCommand(); //Ejecutar consultas (Insert, update, delete, select) SQL en la BD
        public SqlDataAdapter objDataAdapter = new SqlDataAdapter();//un puente entre la BD y la aplicacion.
        DataSet objDs = new DataSet(); //Representa una copia en memoria de la arquitectura de la BD

        public Conexion() {//Constructor e inicializador de los miembros de la clase
            String cadenaCoenxion = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\db_academica.mdf;Integrated Security=True";
            objConexion.ConnectionString = cadenaCoenxion;
            objConexion.Open(); //abrir la BD
        }
        public DataSet obtenerDatos() {
            objDs.Clear();//Limpiar el datase.
            objComando.Connection = objConexion;//Establcer la conexion para ejecutar consultas a la BD

            objDataAdapter.SelectCommand = objComando;

            objComando.CommandText = "SELECT * FROM alumnos";
            objDataAdapter.Fill(objDs, "alumnos"); //tomamos los datos de la BD y llenamos el ds

            objComando.CommandText = "SELECT * FROM materias";
            objDataAdapter.Fill(objDs, "materias");

            objComando.CommandText = "SELECT idUsuario, [usuario ] AS usuario, [clave ] AS clave, [nombre ] AS nombre, [dirección ] AS dirección, [teléfono ] AS teléfono FROM usuarios_usss119326";
            objDataAdapter.Fill(objDs, "usuarios");

            return objDs;
        }
        public string administrarDatosAlumnos(String[] datos, String accion)
        {
            String sql = "";
            if (accion == "nuevo"){
                sql = "INSERT INTO alumnos(codigo,nombre,direccion,telefono,email) VALUES ('" + datos[1] + "', '" + datos[2] + "', '" + datos[3] + "', '" + datos[4] + "', '" + datos[5] + "')";
            }else if (accion == "modificar"){
                sql = "UPDATE alumnos SET codigo='" + datos[1] + "', nombre='" + datos[2] + "', direccion='" + datos[3] + "', telefono='" + datos[4] + "', email='" + datos[5] + "' WHERE idAlumno='" + datos[0] + "'";
            }else if (accion == "eliminar"){
                sql = "DELETE FROM alumnos WHERE idAlumno='" + datos[0] + "'";
            }
            return ejecutarSQL(sql);
        }
        public string administrarDatosMaterias(String[] datos, String accion){
            String sql = "";
            if (accion == "nuevo"){
                sql = "INSERT INTO materias(codigo,nombre,uv) VALUES ('" + datos[1] + "', '" + datos[2] + "', '" + datos[3] + "')";
            }else if (accion == "modificar"){
                sql = "UPDATE materias SET codigo='" + datos[1] + "', nombre='" + datos[2] + "', uv='" + datos[3] + "' WHERE idMateria='" + datos[0] + "'";
            }else if (accion == "eliminar"){
                sql = "DELETE FROM materias WHERE idMateria='" + datos[0] + "'";
            }
            return ejecutarSQL(sql);
        }

        public DataSet crearDs()
        {
            DataSet ds = new DataSet();
            try
            {
                objComando.Connection = objConexion;
                // Renombramos la columna con un alias limpio 'usuario'
                objComando.CommandText = "SELECT idUsuario, [usuario ] AS usuario, [clave ] AS clave, [nombre ] AS nombre, [dirección ] AS dirección, [teléfono ] AS teléfono FROM usuarios_usss119326";
                objDataAdapter.SelectCommand = objComando;

                objDataAdapter.Fill(ds, "usuarios");
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Error al cargar los datos: " + ex.Message);
            }
            return ds;
        }

        public string mantenimiento_usuarios_usss119326(string[] datos, string accion)
        {
            String sql = "";
            // CORREGIDO: Se incluyen los corchetes y espacios en los campos por la estructura de tu base de datos
            if (accion == "nuevo")
            {
                sql = "INSERT INTO usuarios_usss119326([usuario ], [clave ], [nombre ], [dirección ], [teléfono ]) VALUES ('" + datos[1] + "', '" + datos[2] + "', '" + datos[3] + "', '" + datos[4] + "', '" + datos[5] + "')";
            }
            else if (accion == "modificar")
            {
                sql = "UPDATE usuarios_usss119326 SET [usuario ]='" + datos[1] + "', [clave ]='" + datos[2] + "', [nombre ]='" + datos[3] + "', [dirección ]='" + datos[4] + "', [teléfono ]='" + datos[5] + "' WHERE idUsuario='" + datos[0] + "'";
            }
            else if (accion == "eliminar")
            {
                sql = "DELETE FROM usuarios_usss119326 WHERE idUsuario='" + datos[0] + "'";
            }
            return ejecutarSQL(sql);
        }

        public bool validarUsuario(string usuario, string clave)
        {
            bool encontrado = false;
            try
            {
                objComando.Connection = objConexion;
                // Consultamos si existe el usuario con esa clave (respetando los espacios de las columnas)
                objComando.CommandText = "SELECT COUNT(*) FROM usuarios_usss119326 WHERE [usuario ] = '" + usuario + "' AND [clave ] = '" + clave + "'";

                int resultado = Convert.ToInt32(objComando.ExecuteScalar());
                if (resultado > 0)
                {
                    encontrado = true;
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Error en la validación: " + ex.Message);
            }
            return encontrado;
        }
        public String ejecutarSQL(String sql)
        {
            try
            {
                objComando.Connection = objConexion;
                objComando.CommandText = sql;
                return objComando.ExecuteNonQuery().ToString();
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

    }
}
